# Frontend Mentor - Advice generator app solution

This is a solution to the [Advice generator app challenge on Frontend Mentor](https://www.frontendmentor.io/challenges/advice-generator-app-QdUG-13db). Frontend Mentor challenges help you improve your coding skills by building realistic projects.

## Table of contents

- [Overview](#overview)
  - [The challenge](#the-challenge)
  - [Screenshot](#screenshot)
  - [Links](#links)
- [My process](#my-process)
  - [Built with](#built-with)
  - [What I learned](#what-i-learned)
  - [Continued development](#continued-development)
  - [Useful resources](#useful-resources)
- [Author](#author)
- [Acknowledgments](#acknowledgments)


## Overview

### The challenge

Users should be able to:

- Toggle through the advices on both mobile and desktop views.

### Screenshot

![At root of the file](./screenshot.jpg)


### Links

- Solution URL: [Add solution URL here](https://your-solution-url.com)
- Live Site URL: [Add live site URL here](https://your-live-site-url.com)

## My process

### Built with

- Semantic HTML5 markup
- CSS custom properties
- Flexbox
- CSS Grid
- Mobile-first workflow
- [React](https://reactjs.org/) - JS library
- [Styled Components](https://styled-components.com/) - For styles


### What I learned

Use this section to recap over some of your major learnings while working through this project. Writing these out and providing code samples of areas you want to highlight is a great way to reinforce your own knowledge.

I gaimed a lot of knowledge in the useReduce hook of react js. I had other simpler alternatives like useState and useEffect hooks, but I choose the former because I wanted to learn a lot from it. I learnt that, when using async await function, it is best to place it in it's own function outside the useEffect hook then invoke it inside the useEffect. This is because,react expects a regular function and not a promise.

I'm proud of this code below:
```js
const proudOfThisFunc = () => {
  const handleClick = () => {
    axios.get('https://api.adviceslip.com/advice')
      .then(res => {
        console.log(res)
        setPost(res.data.slip)
      })
      .catch(err => {
        console.log(err)
      })
  }
  
  useEffect(() => {
    handleClick()
  }, [])
}
```


### Continued development
I intend to learn more about react and it's related frameworks e.g redux, next and react router amongst others. I alsi want to polish my skills on the back end. Particularly, node js and mongo Db.


### Useful resources

- [Resource 1](https://linguinecode.com/post/getting-started-with-react-useeffect) - This helped me gain some insights on iseEffect hook. I learnt the clean up technique that useEffect gives us, to get rid of the lingering window event.
- [Resource 2](https://devtrium.com/posts/how-to-use-react-usereducer-hook) - Through this article, I was able to gain a good understanding of the useReducet hook.

## Author

- Website - [Fenton Miyare](https://www.your-site.com)
- Frontend Mentor - [@visuallearners](https://www.frontendmentor.io/profile/visuallearners)
- Twitter - [@FentonMiyare](https://github.com/FentonMiyare)

