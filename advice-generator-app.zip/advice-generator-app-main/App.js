import React from 'react'
// import FetchAdvice from './components/FetchAdvice.js'
import AdviceFetch from './components/AdviceFetch'
import DataFetching from './components/DataFetching'

function App() {
  
  //const [showWindowWidthSize, setShowWindowWidthSize] = setState(true)
  
  return (
    <div>
      {/* <DataFetching /> */}
      <AdviceFetch />
    </div>
  )
}

export default App
