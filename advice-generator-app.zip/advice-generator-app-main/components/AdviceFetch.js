import React, {useState, useEffect} from 'react';
import axios from 'axios'

//Fetching Data
function AdviceFetch() {
  const [post, setPost] = useState({})
  const [id, setId] = useState({})
 // const [idFromButtonClick, setIdFromButtonClick] = useState(1)
  
  const handleClick = () => {
    axios.get('https://api.adviceslip.com/advice')
      .then(res => {
        console.log(res)
        setPost(res.data.slip)
      })
      .catch(err => {
        console.log(err)
      })
  }
  
  useEffect(() => {
    handleClick()
  }, [])
  
  return (
      <div className="card">
        <div className="advice">
              advice #{post.id}
        </div>
        <div className="quote">
              {post.advice}
        </div>
        <img className="divider" srcSet="/advice-generator-app-main/images/pattern-divider-mobile.svg" src="/advice-generator-app-main/images/pattern-divider-mobile.svg" alt="divider" />
        <button className="icon" onClick={handleClick}>
          <img srcSet="/advice-generator-app-main/images/icon-dice.svg" src="/advice-generator-app-main/images/icon-dice.svg" alt="icon-dice" />
        </button>
      </div>
  )
}


export default AdviceFetch
